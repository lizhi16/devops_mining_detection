The gVisor logo files are licensed under CC BY-SA 4.0 (Creative Commons
Attribution-ShareAlike 4.0 International).
